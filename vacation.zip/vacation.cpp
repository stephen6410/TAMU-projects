#include <iostream>
#include <fstream>
#include <string>
#include <stdexcept>
#include "provided.h"
#include "functions.h"

using std::ifstream;
using std::string, std::getline;
using std::cout, std::cin, std::endl;
using std::runtime_error;
using std::invalid_argument;
using std::cerr;

int main() {
	int ngames;
	int duration;
	int prefs[MAX_NB_GAMES];
	int plan[366];
	string titlesFile;
	string prefsFile;
	string planFile;
	string gameTitles[MAX_NB_GAMES];
	int start;
	
	cout << "Please enter the number of games and the duration: ";
	cin >> ngames >> duration;
	
	if (ngames > 200) {
		cout << "Invalid input.";
		return 1;
	}
	if (duration < 1 || duration > 365) {
		cout << "Invalid input.";
		return 1;
	}
	
	cout << "Please enter name of file with titles: ";
	cin >> titlesFile;
	
	cout << "Please enter name of file with preferences: ";
	cin >> prefsFile;
	
	cout << "Please enter name of file with plan: ";
	cin >> planFile;
	
	try {
		readGameTitles(titlesFile, ngames, gameTitles);
	}
	catch (std::runtime_error & e) {
		// cout << "Invalid titles file.";
		cerr << e.what() << endl;
		exit(1);
	}
	try {
		readPrefs(prefsFile, ngames, prefs);
	}
	catch (std::runtime_error & e) {
		cout << "Invalid preferences file.";
		cerr << e.what() << endl;
		exit(1);
	}
	try {
		readPlan(planFile, plan);
	}
	catch (std::runtime_error & e) {
		cout << "Invalid plan file.";
		cerr << e.what() << endl;
		exit(1);
	}
	try {
		start = findBestVacation(duration, prefs, plan);
		cout << "Best start day is " << start << endl;
		cout << "Games to be played:" << endl;
		printGamesPlayedInVacation(start, duration, plan, gameTitles, ngames);
	}
	catch (std::invalid_argument &e) {
		cerr << e.what() << endl;
		exit(1);
	}
	
	return 0;
}