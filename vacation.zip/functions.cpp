#include <iostream>
#include <fstream>
#include <string>
#include <stdexcept>
#include "functions.h"

using std::ifstream;
using std::string, std::getline;
using std::cout, std::endl;
using std::runtime_error;
using std::invalid_argument;

void readPrefs(string prefsFile, int ngames, int prefs[]) {
	
	ifstream ifs(prefsFile);
	int MAX_NB_GAMES = 200;
	
    if (!ifs.is_open()) {
        throw runtime_error("Invalid titles file.");
    }
	for (int i = 0; i < ngames; i++) {
		prefs[i] = 0;
	}

    int gameid;
    int rating;
    while (!ifs.eof()) {
		ifs >> gameid;
        if (ifs.good()) {
            ifs >> rating;
            if (gameid >= 0 && gameid < ngames && rating <= 5 && rating >= 0) {
                prefs[gameid] = rating;
            }
		}
    }
	ifs.close();
}

void readPlan(string planFile, int plan[]) {
	
	ifstream ifs(planFile);
    if (!ifs.is_open()) {
        throw runtime_error("Invalid titles file.");
    }

	int day;
    int gameid;
    while (!ifs.eof()) {
		ifs >> day;
        if (ifs.good()) {
            ifs >> gameid;
			plan[day] = gameid;
		}
    }
	ifs.close();
}

int computeFunLevel(int start, int duration, int prefs[], int plan[]) {
	int sum = 0;
	
	for (int i = start; i < (start + duration); ++i) {
		if (i > 365) {
			throw invalid_argument("Invalid input.");
		}
		else {
			sum += prefs[plan[i]];
		}
	}
	
	return sum;
}

int findBestVacation(int duration, int prefs[], int plan[]) {
	int currentFun = 0;
	int mostFun = 0;
	int bestStart;
	
	if (duration < 1 || duration > 365) {
		throw invalid_argument("Invalid input.");
	}
	else {
		for (int start = 1; start < (367 - duration); ++start) {
			currentFun = computeFunLevel(start, duration, prefs, plan);
			if (currentFun > mostFun) {
				mostFun = currentFun;
				bestStart = start;
			}
		}
		return bestStart;
	}
}