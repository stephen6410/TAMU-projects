#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <cmath>
#include "functions.h"

using namespace std;

// Already done
Pixel** createImage(int width, int height) {
	cout << "Start createImage... " << endl;
  
	// Create a one dimensional array on the heap of pointers to Pixels 
	//    that has width elements (i.e. the number of columns)
	Pixel** image = new Pixel*[width];
  
	bool fail = false;
  
	for (int i=0; i < width; ++i) { // loop through each column
		// assign that column to a one dimensional array on the heap of Pixels
		//  that has height elements (i.e. the number of rows)
		image[i] = new Pixel[height];
    
		if (image[i] == nullptr) { // failed to allocate
		fail = true;
		}
	}
  
	if (fail) { // if any allocation fails, clean up and avoid memory leak
		// deallocate any arrays created in for loop
		for (int i=0; i < width; ++i) {
		delete [] image[i]; // deleting nullptr is not a problem
		}
		delete [] image; // dlete array of pointers
		return nullptr;
	}
  
	// initialize cells
	//cout << "Initializing cells..." << endl;
	for (int row=0; row<height; ++row) {
		for (int col=0; col<width; ++col) {
		//cout << "(" << col << ", " << row << ")" << endl;
		image[col][row] = { 0, 0, 0 };
		}
	}
	cout << "End createImage... " << endl;
	return image;
}

void deleteImage(Pixel** image, int width) {
	cout << "Start deleteImage..." << endl;
	// avoid memory leak by deleting the array
	for (int col = 0; col < width; ++col) {
		delete [] image[col]; // delete each individual array placed on the heap
	}
	delete [] image;
	image = nullptr;
}


// Part 1
int* createSeam(int length) {
	int* seam;
	seam = new int[length];
	
	for (int i = 0; i < length; ++i) {
		seam[i] = 0;
	}
	
	return seam;
}

void deleteSeam(int* seam) {
	delete [] seam;
}

bool loadImage(string filename, Pixel** image, int width, int height) {
	ifstream ifs(filename);
  
	if (!ifs.is_open()) {
		cout << "Error: failed to open input file - " << filename << endl;
		return false;
	}
  
	char type[3];
	ifs >> type;
	if ((toupper(type[0]) != 'P') || (type[1] != '3')) {
		cout << "Error: type is " << type << " instead of P3" << endl;
		return false;
	}
	
	int w = 0, h = 0;
	ifs >> w >> h;
	if (ifs.fail()) {
		cout << "Error: read non-integer value" << endl;
		return false;
	}
	if (w != width) {
		cout << "Error: input width (" << width << ") does not match value in file (" << w << ")" << endl;
		return false;
	}
	if (h != height) {
		cout << "Error: input height (" << height << ") does not match value in file (" << h << ")" << endl;
		return false;
	}
	
	int colorMax = 0;
	ifs >> colorMax;
	if (ifs.fail()) {
		cout << "Error: read non-integer value" << endl;
		return false;
	}
	if (colorMax != 255) {
		cout << "Error: invalid color max value" << endl;
		return false;
	}
	
	int red; int green; int blue;
	for (int row = 0; row < height; ++row) {
        for(int col = 0; col < width; ++col) {
            ifs >> image[col][row].r;
			red = image[col][row].r;
			if (red > 255 || red < 0) {
				cout << "Error: invalid color value " << red;
				return false;
			}
			ifs >> image[col][row].g;
            green = image[col][row].g;
			if (green > 255 || green < 0) {
				cout << "Error: invalid color value " << green;
				return false;
			}
			ifs >> image[col][row].b;
            blue = image[col][row].b;
			if (blue > 255 || blue < 0) {
				cout << "Error: invalid color value " << blue;
				return false;
			}
			
			if (ifs.eof() && ifs.fail()) {
				cout << "Error: not enough color values";
				return false;
			}
			else if (ifs.fail()) {
				cout << "Error: read non-integer value";
				return false;
			}
        }
    }

	int extraColor;
	if (!ifs.eof()) {
		ifs >> extraColor;
		if (!ifs.fail()) {
			cout << "Error: too many color values" << endl;
			return false;
		}
	}
	
	ifs.close();
	return true;
}

bool outputImage(string filename, Pixel** image, int width, int height) {
    ofstream ofs(filename);

    if (!ofs.is_open()) {
        cout << "Did not open";
		return false;
	}
    char type[3] = "P3";
    ofs << type << '\n';
    ofs << width << ' ' << height << '\n';
    
    int red;
    int green;
    int blue;
    
    for(int col = 0; col < width; ++col) {
        for (int row = 0; row < height; ++row) {
            red = image[col][row].r;
            green = image[col][row].g;
            blue = image[col][row].b;
            
            ofs << red << ' ';
            ofs << green << ' ';
            ofs << blue << ' ';
        }
        ofs << '\n';
    }
	return true;
}

int energy(Pixel** image, int x, int y, int width, int height) {
	int xr; int xl; int yr; int yl;
	int redRight; int redLeft; int red;
	int greenRight; int greenLeft; int green;
	int blueRight; int blueLeft; int blue;
	int xnrg; int ynrg; int nrg;
	if(x == 0){
		xr = x + 1;
		xl = width - 1;
	}
	else if (x+1 == width) {
		xr = 0;
		xl = x - 1;
	}
	else {
		xr = x + 1;
		xl = x - 1;
	}
	redRight = image[xr][y].r;
	redLeft = image[xl][y].r;
	greenRight = image[xr][y].g;
	greenLeft = image[xl][y].g;
	blueRight = image[xr][y].b;
	blueLeft = image[xl][y].b;
	
	red = redRight - redLeft;
	green = greenRight - greenLeft;
	blue = blueRight - blueLeft;
	xnrg = red*red + green*green + blue*blue;
	
	if (y == 0) {
		yr = y + 1;
		yl = height - 1;
	}
	else if (y + 1 == height) {
		yr = y - 1;
		yl = 0;
	}
	else {
		yr = y - 1;
		yl = y + 1;
	}
	redRight = image[x][yr].r;
	redLeft = image[x][yl].r;
	greenRight = image[x][yr].g;
	greenLeft = image[x][yl].g;
	blueRight = image[x][yr].b;
	blueLeft = image[x][yl].b;
	
	red = redRight - redLeft;
	green = greenRight - greenLeft;
	blue = blueRight - blueLeft;
	ynrg = red*red + green*green + blue*blue;
	
	nrg = xnrg + ynrg;
	return nrg;
}


// Part 2
int loadVerticalSeam(Pixel** image, int start_col, int width, int height, int* seam) {
	int totalEnergy = energy(image, start_col, 0, width, height);
	int currentEnergy; seam[0] = start_col;
	int col = start_col; int left_col = start_col; int right_col = start_col;
	int forward; int left; int right;
	for (int row = 1; row < height; ++row) {
		if (col != width - 1) {
			left_col += 1;
		}
		if (col != 0) {
			right_col -= 1;
		}
		forward = energy(image, col, row, width, height);
		left = energy(image, left_col, row, width, height);
		right = energy(image, right_col, row, width, height);
			
		if ((right < forward) && (right < left)) {
			currentEnergy = right;
			--col;
		} else if ((left <= right) && (left < forward)) {
			currentEnergy = left;
			++col;
		} else {
			currentEnergy = forward;
		}
		left_col = col;
		right_col = col;
		seam[row] = col;
		totalEnergy += currentEnergy;
	}
	
	return totalEnergy;
}

int* findMinVerticalSeam(Pixel** image, int width, int height) {
	int* seam = createSeam(height);
	int min_col = 0;
	int min_seam_energy = loadVerticalSeam(image, min_col, width, height, seam);
	int curr_seam_energy;
	
	for (int col = 1; col < width; ++col) {
		curr_seam_energy = loadVerticalSeam(image, col, width, height, seam);
		if (curr_seam_energy < min_seam_energy) {
			min_seam_energy = curr_seam_energy;
			min_col = col;
		}
	}
	min_seam_energy = loadVerticalSeam(image, min_col, width, height, seam);
	
	return seam;
}

void removeVerticalSeam(Pixel** image, int width, int height, int* verticalSeam) {
	for (int row = 0; row < height; ++row) {		
		for (int col = verticalSeam[row]; col < width-1; ++col) {
			image[col][row] = image[col + 1][row];
		}
	}
}

int loadHorizontalSeam(Pixel** image, int start_row, int width, int height, int* seam) {
	int totalEnergy = energy(image, 0, start_row, width, height);
	int currentEnergy; seam[0] = start_row;
	int row = start_row; int left_row = start_row; int right_row = start_row;
	int forward; int left; int right;
	for (int col = 1; col < width; ++col) {
		if (row != 0) {
			left_row -= 1;
		}
		if (row != height - 1) {
			right_row += 1;
		}
		forward = energy(image, col, row, width, height);
		left = energy(image, col, left_row, width, height);
		right = energy(image, col, right_row, width, height);
			
		if ((right < forward) && (right < left)) {
			currentEnergy = right;
			++row;
		} else if ((left <= right) && (left < forward)) {
			currentEnergy = left;
			--row;
		} else {
			currentEnergy = forward;
		}
		left_row = row;
		right_row = row;
		seam[col] = row;
		totalEnergy += currentEnergy;
	}
	
	return totalEnergy;
}

int* findMinHorizontalSeam(Pixel** image, int width, int height) {
	int* seam = createSeam(width);
	int min_row = 0;
	int min_seam_energy = loadHorizontalSeam(image, min_row, width, height, seam);
	int curr_seam_energy;
	
	for (int row = 1; row < height; ++row) {
		curr_seam_energy = loadHorizontalSeam(image, row, width, height, seam);
		if (curr_seam_energy < min_seam_energy) {
			min_seam_energy = curr_seam_energy;
			min_row = row;
		}
	}
	min_seam_energy = loadHorizontalSeam(image, min_row, width, height, seam);
	
	return seam;
}

void removeHorizontalSeam(Pixel** image, int width, int height, int* horizontalSeam) {
	for (int col = 0; col < width; ++col) {		
		for (int row = horizontalSeam[col]; row < height-1; ++row) {
			image[col][row] = image[col][row + 1];
		}
	}
}