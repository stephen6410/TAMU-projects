#ifndef DOUBLYLINKEDLIST_H
#define DOUBLYLINKEDLIST_H
#include "Node.h"
#include <string>
#include <iostream>
#include <iomanip>
#include <sstream>

//////////////////////////////////////////////////////////////////////////////
//                         class template definition                        //
//////////////////////////////////////////////////////////////////////////////

template<typename T>
class DoublyLinkedList {
public:
    DoublyLinkedList();
    DoublyLinkedList(T data);
    DoublyLinkedList(const DoublyLinkedList<T>& needsCopy);
    DoublyLinkedList<T>& operator=(const DoublyLinkedList<T>& needsCopy);
    ~DoublyLinkedList();
    unsigned int size() const { return sz; }
    T& front();
    const T& front() const;
    T& back();
    const T& back() const;
    void push_back(T data);
    void push_front(T data);
    void pop_back();
    void pop_front();
    void erase(unsigned int);
    void insert(T data, unsigned int idx);
    void clear();
    std::string to_str() const;
    template<typename U>
	friend bool operator==(DoublyLinkedList<U> const& lhs, DoublyLinkedList<U> const& rhs);
private:
    Node<T> *head;
    Node<T> *tail;
    unsigned int sz;
};

template <typename T>
DoublyLinkedList<T>::DoublyLinkedList() : head(nullptr), tail(nullptr), sz(0) {}

template <typename T>
DoublyLinkedList<T>::DoublyLinkedList(T data) {
    head = nullptr;
    tail = nullptr;
    sz = 0;
	
    Node<T> *node = new Node<T>(data);
    head = node;
    tail = node;
    ++sz;
}

template <typename T>
DoublyLinkedList<T>::DoublyLinkedList(const DoublyLinkedList<T>& needs_copy) {
    head = nullptr;
    tail = nullptr;
    sz = 0;
	
	Node<T> *dummy = needs_copy.head;
    clear();
    while (dummy) {
        push_back(dummy -> data);
        dummy = dummy -> next;
    }
}

template <typename T>
DoublyLinkedList<T>& DoublyLinkedList<T>::operator=(const DoublyLinkedList<T>& needs_copy) {
    Node<T> *dummy = needs_copy.head;
    while (dummy) {
        this -> push_back(dummy -> data);
        dummy = dummy -> next;
    }
}

template <typename T>
DoublyLinkedList<T>::~DoublyLinkedList() {
    clear();
}

template <typename T>
T& DoublyLinkedList<T>::front() {
    return head -> data;
}

template <typename T>
const T& DoublyLinkedList<T>::front() const {
    return head -> data;
}

template <typename T>
T& DoublyLinkedList<T>::back() {
    return tail -> data;
}

template <typename T>
const T& DoublyLinkedList<T>::back() const {
    return tail -> data;
}

template <typename T>
void DoublyLinkedList<T>::push_back(T data) {
    Node<T> *node = new Node<T>(data);
    if (head) {
		tail -> next = node;
		node -> prev = tail;
		tail = node;
		node -> next = nullptr;
	}
    else {
        head = node;
    }
    tail = node;
    ++sz;
}

template <typename T>
void DoublyLinkedList<T>::push_front(T data) {
    Node<T> *node = new Node<T>(data);
    if (head) {
        head -> prev = node;
        node -> prev = nullptr;
        node -> next = head;
    }
	else {
        tail = node;
    }
    head = node;
    ++sz;
}

template <typename T>
void DoublyLinkedList<T>::pop_back() {
	if (sz == 0) {
		return;
	}
	else if (sz == 1) {
		Node<T> *dummy = head;
		delete dummy;
		head = nullptr;
		tail = nullptr;
		--sz;
	}
	else {
		Node<T>* dummy = tail;
		tail = tail -> prev;
		tail -> next = nullptr;
		delete dummy;
		--sz;
	}
}

template <typename T>
void DoublyLinkedList<T>::pop_front() {
    if (sz == 0) {
        return;
    }
    else if (sz == 1) {
        Node<T> *dummy = head;
        delete dummy;
        head = nullptr;
        tail = nullptr;
        --sz;
    }
    else {
        Node<T> *dummy = head->next;
        if (dummy != nullptr) {
            dummy -> prev = nullptr;
        }
        delete head;
        head = dummy;
        --sz;
    }
}

template <typename T>
void DoublyLinkedList<T>::erase(unsigned int idx) {
    if ((idx >= sz) || (idx < 0)) {
        return;
    }
    else if (idx == (sz - 1)) {
        pop_back();
    }
    else if (idx == 0) {
        pop_front();
    }
    else if (sz == 1) {
        Node<T> *dummy = head;
        delete dummy;
        head = nullptr;
        tail = nullptr;
        --sz;
    }
    else {
		Node<T> *dummy = head;
		for (int i = 0; i < idx; ++i) {
			dummy = dummy -> next;
		}
		Node<T> *node = dummy -> next;
		dummy -> next -> prev = dummy -> prev;
		dummy -> prev -> next = node;
		delete dummy;
		--sz;
	}
}

template <typename T>
void DoublyLinkedList<T>::insert(T data, unsigned int idx) {
	if ((idx >= sz) || (idx < 0)) {
		return;
	}
	else if (idx == sz) {
		push_back(data);
	}
	else if (idx == 0) {
		push_front(data);
	}
	else {
		Node<T> *dummy = head;
		Node<T> *new_node = new Node<T>(data);
		for (int i = 0; i < idx; ++i) {
			dummy = dummy -> next;
		}
		
		if (!dummy) {
			return;
		}
		else {
			new_node -> prev = dummy -> prev;
			new_node -> next = dummy;
			dummy -> prev -> next = new_node;
			dummy -> prev = new_node;
			++sz;
		}
	}
}

template <typename T>
void DoublyLinkedList<T>::clear() {
    Node<T> *dummy = head;
    while (dummy) {
        Node<T> *next = dummy -> next;
        delete dummy;
        dummy = next;
    }
    head = nullptr;
    tail = nullptr;
	sz = 0;
}

//////////////////////////////////////////////////////////////////////////////
//                       helper function declarations                       //
//////////////////////////////////////////////////////////////////////////////

template<typename T>
bool operator==(DoublyLinkedList<T> const&, DoublyLinkedList<T> const&);

template<typename T>
bool operator!=(DoublyLinkedList<T> const&, DoublyLinkedList<T> const&);

template<typename T>
std::ostream& operator<<(std::ostream &, DoublyLinkedList<T> const&);

//////////////////////////////////////////////////////////////////////////////
//                     member template function definitions                 //
//////////////////////////////////////////////////////////////////////////////

template<typename T>
std::string DoublyLinkedList<T>::to_str() const {
    std::stringstream os;
    const Node<T> *dummy = head;
    os << std::endl << std::setfill('-') << std::setw(80) << '-' << std::setfill(' ') << std::endl;
    os << "head: " << head << std::endl;
    os << "tail: " << tail << std::endl;
    os << "  sz: " << sz << std::endl;
    os << std::setw(16) << "node" << std::setw(16) << "node.prev" << std::setw(16) << "node.data" <<  std::setw(16) << "node.next" << std::endl;
    while (dummy) {
        os << std::setw(16) << dummy;
        os << std::setw(16) << dummy -> prev;
        os << std::setw(16) << dummy -> data;
        os << std::setw(16) << dummy -> next;
        os << std::endl;
        dummy = dummy -> next;
    }
    os << std::setfill('-') << std::setw(80) << '-' << std::setfill(' ') << std::endl;
    return os.str();
}

//////////////////////////////////////////////////////////////////////////////
//                     helper template function definitions                 //
//////////////////////////////////////////////////////////////////////////////

template<typename T>
bool operator==(DoublyLinkedList<T> const& lhs, DoublyLinkedList<T> const& rhs) {
    if (lhs.sz != rhs.sz) {
		return false;
	}
	else {
		Node<T> *lh_node = lhs.head;
        Node<T> *rh_node = rhs.head;
        while (rh_node != nullptr) {
            if (*lh_node == *rh_node){
                lh_node = lh_node -> next;
				rh_node = rh_node -> next;
            }
			else {
				return false;
			}
        }
        return true;
    }
}

template <typename T>
bool operator!=(DoublyLinkedList<T> const& lhs, DoublyLinkedList<T> const& rhs) {
    if (lhs.sz != rhs.sz) {
		return true;
	}
	else {
		return false;
	}
}

template<typename T>
std::ostream& operator<<(std::ostream& os, DoublyLinkedList<T> const& rhs) {
    os << rhs.to_str();
    return os;
}

#endif